// VOIDGRAB Instagram downloader function — FIXED v2.0
// Modes:
//   ?status=1                -> health check
//   ?url=<instagram_url>     -> fetch media links from RapidAPI
//   ?proxy=1&url=<media_url> -> proxy media as a forced download

const API_HOST = 'instagram-post-reels-stories-downloader-api.p.rapidapi.com';
const API_TIMEOUT_MS = 18000;
const PROXY_TIMEOUT_MS = 26000;

// BUG FIX #1: Netlify has a 6MB response body limit for functions.
// Files larger than ~4.5MB base64-encoded exceed this. We cap proxy at 4MB raw.
const PROXY_MAX_BYTES = 4 * 1024 * 1024;

exports.handler = async function (event, context) {
  const requestId = context && context.awsRequestId
    ? context.awsRequestId
    : `vg_${Date.now()}`;

  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Accept',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Cache-Control': 'no-store',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers: corsHeaders, body: '' };
  }
  if (event.httpMethod !== 'GET') {
    return json(405, { error: 'Method not allowed', requestId }, corsHeaders);
  }

  const params = event.queryStringParameters || {};

  // Health check
  if (params.status === '1') {
    return json(200, {
      ok: true,
      service: 'VOIDGRAB API',
      requestId,
      timestamp: new Date().toISOString(),
    }, corsHeaders);
  }

  // BUG FIX #2: Properly decode and sanitize the URL parameter.
  // Previously raw param was used without decodeURIComponent, breaking
  // URLs that were double-encoded by the frontend encodeURIComponent call.
  const rawParam = (params.url || '').trim();
  if (!rawParam) {
    return json(400, { error: 'URL parameter missing', requestId }, corsHeaders);
  }

  let targetUrl;
  try {
    targetUrl = decodeURIComponent(rawParam);
    // Reject javascript:, data:, file: schemes — security sanitization
    const parsed = new URL(targetUrl);
    if (!['http:', 'https:'].includes(parsed.protocol)) {
      throw new Error('Invalid protocol');
    }
  } catch (e) {
    return json(400, { error: 'Invalid URL format.', requestId }, corsHeaders);
  }

  // Route: proxy request
  if (params.proxy === '1') {
    return proxyMedia(targetUrl, corsHeaders, requestId);
  }

  // Route: fetch media info
  if (!isValidInstagramUrl(targetUrl)) {
    return json(400, {
      error: 'Please paste a valid public Instagram Reel, post, TV, or share URL.',
      requestId,
    }, corsHeaders);
  }

  const rapidApiKey = process.env.RAPIDAPI_KEY;
  if (!rapidApiKey) {
    console.error('[VOIDGRAB]', requestId, 'Missing RAPIDAPI_KEY env var');
    return json(500, {
      error: 'Server configuration error — the downloader API key is not set up.',
      requestId,
    }, corsHeaders);
  }

  try {
    // BUG FIX #3: The API URL was built with encodeURIComponent which is correct,
    // but targetUrl must NOT be re-encoded since it was already decoded above.
    const apiUrl = `https://${API_HOST}/instagram/?url=${encodeURIComponent(targetUrl)}`;
    const response = await fetchWithRetry(apiUrl, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'x-rapidapi-host': API_HOST,
        'x-rapidapi-key': rapidApiKey,
        'User-Agent': 'VOIDGRAB/2.0 (+https://instaviddown.netlify.app)',
      },
    }, API_TIMEOUT_MS, 2, requestId);

    const rawText = await response.text();
    console.log('[VOIDGRAB]', requestId, 'RapidAPI status', response.status,
      'bytes', rawText.length);

    if (!response.ok) {
      if (response.status === 401 || response.status === 403) {
        return json(502, {
          error: 'API credentials rejected. Please try again later.',
          requestId,
        }, corsHeaders);
      }
      if (response.status === 429) {
        return json(429, {
          error: 'Rate limit reached. Please wait a moment and try again.',
          requestId,
        }, corsHeaders);
      }
      if (response.status === 404) {
        return json(404, {
          error: 'Video not found. The post may have been deleted or is private.',
          requestId,
        }, corsHeaders);
      }
      return json(502, {
        error: 'Instagram provider could not load this page. Copy a fresh public link and retry.',
        requestId,
      }, corsHeaders);
    }

    // BUG FIX #4: Guard against empty body before JSON.parse.
    let data;
    try {
      data = rawText && rawText.trim() ? JSON.parse(rawText) : {};
    } catch (err) {
      console.error('[VOIDGRAB]', requestId, 'Invalid JSON from provider:', rawText.slice(0, 200));
      return json(502, {
        error: 'Downloader provider returned an invalid response. Retry shortly.',
        requestId,
      }, corsHeaders);
    }

    const normalized = normalizeProviderResponse(data);

    if (!normalized.links.length) {
      return json(404, {
        error: 'No downloadable media found. The Reel may be private, expired, or geo-restricted.',
        requestId,
      }, corsHeaders);
    }

    // BUG FIX #5: Return BOTH raw data and normalized in response so frontend
    // can use server-normalized links preferentially (avoids double-parsing bugs).
    return json(200, {
      ...data,
      normalized,
      requestId,
    }, corsHeaders);

  } catch (err) {
    console.error('[VOIDGRAB]', requestId, 'Function error', err.name, err.message);
    const timedOut = err.name === 'AbortError' || /timeout/i.test(err.message);
    return json(timedOut ? 504 : 502, {
      error: timedOut
        ? 'Request timed out while contacting the provider. Retry with a fresh link.'
        : 'Failed to reach downloader provider. Please try again.',
      requestId,
    }, corsHeaders);
  }
};

// ─── Proxy handler ───────────────────────────────────────────────────────────
async function proxyMedia(targetUrl, corsHeaders, requestId) {
  if (!isSafeProxyUrl(targetUrl)) {
    return json(400, {
      error: 'Proxy URL must be a valid HTTPS media URL.',
      requestId,
    }, corsHeaders);
  }

  try {
    const response = await fetchWithTimeout(targetUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 12; Mobile) AppleWebKit/537.36 Chrome/125 Mobile Safari/537.36',
        'Referer': 'https://www.instagram.com/',
        'Accept': 'video/mp4,video/*,audio/*,*/*;q=0.8',
      },
    }, PROXY_TIMEOUT_MS);

    if (!response.ok) {
      console.error('[VOIDGRAB]', requestId, 'Proxy upstream status', response.status);
      return json(502, {
        error: 'Direct download source failed. Use the fallback link.',
        requestId,
      }, corsHeaders);
    }

    // BUG FIX #6: Stream response into ArrayBuffer and check size BEFORE
    // converting to base64. Previously the function would crash on large files
    // or silently return a truncated base64 blob.
    const buffer = await response.arrayBuffer();

    if (buffer.byteLength > PROXY_MAX_BYTES) {
      console.warn('[VOIDGRAB]', requestId, 'Proxy file too large:', buffer.byteLength);
      return json(413, {
        error: 'FILE_TOO_LARGE',
        message: `File is ${(buffer.byteLength / 1024 / 1024).toFixed(1)} MB — too large for server proxy. Use the fallback link.`,
        requestId,
      }, corsHeaders);
    }

    const contentType = response.headers.get('content-type') || guessContentType(targetUrl);
    const ext = contentType.includes('audio') ? 'mp3' : 'mp4';

    // BUG FIX #7: content-length header must be the ORIGINAL byte length,
    // NOT the base64 length. Sending the base64 length caused broken downloads.
    return {
      statusCode: 200,
      headers: {
        ...corsHeaders,
        'Content-Type': contentType,
        'Content-Disposition': `attachment; filename="voidgrab_download.${ext}"`,
        'Content-Length': String(buffer.byteLength),
        'Accept-Ranges': 'bytes',
      },
      body: Buffer.from(buffer).toString('base64'),
      isBase64Encoded: true,
    };
  } catch (err) {
    console.error('[VOIDGRAB]', requestId, 'Proxy error', err.name, err.message);
    const timedOut = err.name === 'AbortError' || /timeout/i.test(err.message);
    return json(timedOut ? 504 : 502, {
      error: timedOut
        ? 'Download proxy timed out. Use the fallback link.'
        : 'Proxy download failed. Use the fallback link.',
      requestId,
    }, corsHeaders);
  }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────
function json(statusCode, payload, headers) {
  return {
    statusCode,
    headers: { ...headers, 'Content-Type': 'application/json; charset=utf-8' },
    body: JSON.stringify(payload),
  };
}

function isValidInstagramUrl(value) {
  try {
    const url = new URL(value);
    const host = url.hostname.replace(/^www\./, '').toLowerCase();
    // BUG FIX #8: Also accept /stories/ and /s/ (share short links)
    return ['instagram.com', 'instagr.am'].includes(host) &&
      /(\/)(reel|p|tv|share|stories|s)(\/)/.test(url.pathname);
  } catch (err) {
    return false;
  }
}

function isSafeProxyUrl(value) {
  try {
    const url = new URL(value);
    // Block SSRF: reject local/private IPs and non-HTTPS
    if (url.protocol !== 'https:') return false;
    const blocklist = ['localhost', '127.0.0.1', '0.0.0.0', '::1',
      '169.254.169.254', '10.', '192.168.', '172.16.'];
    return !blocklist.some(b => url.hostname === b || url.hostname.startsWith(b));
  } catch (err) {
    return false;
  }
}

async function fetchWithRetry(url, options, timeoutMs, retries, requestId) {
  let lastError;
  for (let attempt = 0; attempt <= retries; attempt += 1) {
    try {
      const response = await fetchWithTimeout(url, options, timeoutMs);
      if (![408, 425, 429, 500, 502, 503, 504].includes(response.status) ||
          attempt === retries) {
        return response;
      }
      console.warn('[VOIDGRAB]', requestId, 'Retry attempt', attempt + 1,
        'status', response.status);
      await delay(500 * (attempt + 1));
    } catch (err) {
      lastError = err;
      if (attempt === retries) throw err;
      console.warn('[VOIDGRAB]', requestId, 'Retry after error', err.name);
      await delay(500 * (attempt + 1));
    }
  }
  throw lastError || new Error('Provider request failed');
}

async function fetchWithTimeout(url, options, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

// BUG FIX #9: The original scan() function had its null-guard AFTER property
// access — this caused "Cannot read properties of null" crashes when the API
// returned null items inside arrays. Fixed by null-checking FIRST.
function normalizeProviderResponse(data) {
  const root = data && (data.result || data.data || data);
  const links = [];
  const seen = new Set();
  let title = '';
  let thumbnail = '';
  let duration = '';
  let fileSize = '';

  function push(url, quality, type) {
    if (!url || typeof url !== 'string') return;
    if (!/^https?:\/\//i.test(url)) return;
    if (seen.has(url)) return;
    // Filter out Instagram page URLs (not media URLs)
    if (/instagram\.com\/(reel|p|tv|stories)\//i.test(url)) return;
    seen.add(url);
    links.push({ url, quality: quality || 'HD', type: type || 'video' });
  }

  function scan(obj) {
    // NULL GUARD MUST BE FIRST — original code accessed obj.url BEFORE this check
    if (!obj || typeof obj !== 'object') return;

    // Accumulate metadata
    title = title || obj.title || obj.caption || obj.description || '';
    thumbnail = thumbnail || obj.thumbnail || obj.thumbnail_url ||
                obj.thumb || obj.cover || obj.image || '';
    duration = duration || obj.duration || obj.video_duration || '';
    fileSize = fileSize || obj.file_size || obj.filesize || obj.size || '';

    // Extract direct URL fields
    ['download_url', 'video_url', 'url', 'src', 'hd', 'sd'].forEach((key) => {
      push(obj[key], obj.quality || obj.label || key.toUpperCase(), obj.type);
    });

    // Recurse into known array fields
    ['links', 'versions', 'medias', 'media', 'videos', 'items', 'resources'].forEach((key) => {
      if (Array.isArray(obj[key])) {
        obj[key].forEach((item) =>
          typeof item === 'string' ? push(item, 'HD', 'video') : scan(item)
        );
      }
    });
  }

  if (Array.isArray(root)) {
    root.forEach(scan);
  } else {
    scan(root);
  }

  return {
    title:     title     || 'Instagram Reel',
    thumbnail: thumbnail || '',
    duration:  duration  || 'Unknown',
    fileSize:  fileSize  || 'Calculated on download',
    quality:   links[0]  ? links[0].quality : 'HD',
    links,
  };
}

function guessContentType(url) {
  if (/\.mp3(\?|$)/i.test(url)) return 'audio/mpeg';
  if (/\.webm(\?|$)/i.test(url)) return 'video/webm';
  return 'video/mp4';
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
